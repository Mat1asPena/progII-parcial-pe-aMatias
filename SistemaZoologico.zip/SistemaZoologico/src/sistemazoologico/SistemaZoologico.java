package sistemazoologico;

public class SistemaZoologico { 
    public static void main(String[] args) {
        Zoologico zoo = new Zoologico();
        
        try {
            Mamifero leon = new Mamifero("Leon", 5, 190.5, Dieta.CARNIVORO);
            Ave aguila = new Ave("Aguila", 3, 15.0, Dieta.CARNIVORO, 2.1);
            Reptil cocodrilo = new Reptil("Cocodrilo", 7, 350, Dieta.CARNIVORO, "Escamas gruesas", "Ectotermia");
            Reptil cocodrilo1 = new Reptil("Cocodrilo", 7, 350, Dieta.CARNIVORO, "Escamas gruesas", "Ectotermia");

            zoo.agregarAnimal(leon);
            zoo.agregarAnimal(aguila);
            zoo.agregarAnimal(cocodrilo);
            // zoo.agregarAnimal(cocodrilo1); 

            zoo.mostrarAnimales();
            zoo.vacunarAnimales();
        }
        
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
