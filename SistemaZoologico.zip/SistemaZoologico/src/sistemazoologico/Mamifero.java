package sistemazoologico;

public class Mamifero extends Animal{

    public Mamifero(String nombre, int edad, double peso, Dieta dieta) {
        super(nombre, edad, peso, dieta, true);
    }
    
    public void vacunar() {
       System.out.println(nombre + " ha sido vacunado.");
   }

    @Override
    public void mostrarInfo() {
        System.out.println("Mamifero - Peso: " + peso + 
                " kg, Dieta: " + dieta);
    }
    
}
