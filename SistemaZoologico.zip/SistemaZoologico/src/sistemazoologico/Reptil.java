package sistemazoologico;

public class Reptil extends Animal{
    private String tipoEscama;
    private String regulacionTemperatura;

    public Reptil(String nombre, int edad, double peso, Dieta dieta, String tipoEscama,String regulacionTemperatura) {
        super(nombre, edad, peso, dieta, false);
        this.tipoEscama = tipoEscama;
        this.regulacionTemperatura = regulacionTemperatura;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Reptil -  Tipo de Escama: " + tipoEscama + 
                ", Regulacion de Temperatura: " + regulacionTemperatura);
    }
}
